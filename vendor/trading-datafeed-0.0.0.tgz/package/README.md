# @trading/datafeed

Datafeeds for `@trading/chart`. The chart takes any object that implements `IDatafeed`, so you can use one of the built-in exchange feeds or connect your own data.

## Built-in feeds

```ts
import { BinanceDatafeed, CoinbaseDatafeed, createExchangeDatafeed } from "@trading/datafeed";

const feed = createExchangeDatafeed("bybit", "futures");
```

## Your own data: ready-made templates

`@trading/datafeed/examples` ships three feeds you can configure with your own endpoints. You can also copy one as the starting point for a custom feed.

| Class | Use when |
| --- | --- |
| `StaticDatafeed` | You already have the candles in memory (CSV, backtest, DB export). `push()` streams updates. |
| `RestPollingDatafeed` | You have a REST candles endpoint and no WebSocket. Live candles come from polling. |
| `WebSocketDatafeed` | You have REST history plus a WebSocket candle stream. |

```ts
import { TradingChart } from "@trading/chart";
import { WebSocketDatafeed } from "@trading/datafeed/examples";

const datafeed = new WebSocketDatafeed({
  maxBarsPerRequest: 500,
  historyUrl: (r) =>
    `https://api.example.com/candles?s=${r.symbol}&tf=${r.resolution}&limit=${r.countBack}` +
    (r.startTime != null ? `&start=${r.startTime}` : `&end=${r.to}`),
  parseHistory: (body) =>
    (body as number[][]).map(([t, o, h, l, c, v]) => ({ time: t, open: o, high: h, low: l, close: c, volume: v })),
  streamUrl: () => "wss://stream.example.com",
  subscribeMessage: (o) => JSON.stringify({ op: "subscribe", channel: `candles.${o.resolution}.${o.symbol}` }),
  parseMessage: (data) => {
    const m = JSON.parse(data);
    if (m.type !== "candle") return null;
    return { bar: { time: m.t, open: m.o, high: m.h, low: m.l, close: m.c, volume: m.v }, isClosed: m.final };
  },
});

new TradingChart(container, { symbol: "BTCUSD", resolution: "15", datafeed });
```

```ts
import { StaticDatafeed } from "@trading/datafeed/examples";

const datafeed = new StaticDatafeed({ bars: { MYSYM: myOneMinuteBars }, baseResolution: "1" });
datafeed.push("MYSYM", latestBar); // live update
```

## Writing a feed from scratch

Implement `IDatafeed`:

```ts
import type { IDatafeed, HistoryRequest, HistoryResponse } from "@trading/datafeed";

class MyDatafeed implements IDatafeed {
  readonly maxBarsPerRequest = 500;          // optional, default 1000
  onReady(cb: () => void) { cb(); }
  async resolveSymbol(symbol: string) { /* return SymbolInfo */ }
  async getHistory(req: HistoryRequest): Promise<HistoryResponse> { /* ... */ }
  subscribeBars(opts, onBar) { /* return a subscription id */ }
  unsubscribeBars(id: string) { /* ... */ }
  // optional: subscribeOrderBook, unsubscribeOrderBook, setMarket, destroy
}
```

### Rules for `getHistory`

- **Bars** are `{ time, open, high, low, close, volume? }`, sorted oldest first. `time` is the candle's **open time in Unix seconds**.
- **Backward request** (no `startTime`): return up to `countBack` bars ending at or before `to`.
- **Forward request** (`startTime` set): return up to `countBack` bars starting at or after `startTime`. The chart sends these for replay and "go to date".
- **`noData`**: set it to `true` when there are no more bars in the requested direction. If you leave it out, the chart treats a page shorter than `countBack` as the last one.
- The chart never asks for more than `maxBarsPerRequest` bars per call.

### Rules for `subscribeBars`

- Call `onBar(bar, isClosed)` whenever the current candle changes. A bar with the same `time` as the last one updates it; a bar with a later `time` starts a new candle.
- Pass `isClosed = true` when a candle is final, if your source tells you.
- `unsubscribeBars` and `destroy` must close sockets and timers.

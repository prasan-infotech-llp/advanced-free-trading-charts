# @trading/terminal

The complete charting terminal as one React component: top toolbar (symbol search,
market, intervals, chart type, indicators, replay), drawing tools, indicator legends and
settings, bar replay, and the right-click price-axis menu.

## Install

From this repo, build and pack the libraries:

```bash
npm run pack:libs          # writes dist-libs/*.tgz
```

In the other project (React 18 or 19):

```bash
npm install /path/to/trading/dist-libs/*.tgz
```

## Use

```jsx
import { TradingTerminal } from "@trading/terminal";
import "@trading/terminal/styles.css";

export function Chart() {
  return (
    <div style={{ height: "100vh" }}>       {/* the terminal fills its parent */}
      <TradingTerminal symbol="ETHUSDT" resolution="60" logoUrl="/logo.png" />
    </div>
  );
}
```

## Props

| Prop | Default | Notes |
|---|---|---|
| `symbol` | `"BTCUSDT"` | Initial symbol |
| `market` | `"spot"` | `"spot" \| "futures" \| "coin_m" \| "options"` |
| `resolution` | `"15"` | `"1" "2" "3" "5" "10" "15" "30" "45"` (minutes), `"60" "120" "180" "240"` (hours), `"D" "W" "M" "3M" "6M" "12M"`. Binance has no 2m, 10m, 45m, 3h or multi-month candles, so those are built from 1m / 5m / 15m / 1h / 1M candles, for history and live |
| `chartType` | `"candlestick"` | Also `hollow_candles`, `heikin_ashi`, `bars`, `line`, `area` |
| `logoUrl` | — | Watermark image, bottom-left of the chart |
| `theme` | light theme | Partial chart colours, e.g. `{ upColor, downColor, grid }` |
| `datafeed` | Binance, direct | `new BinanceDatafeed({ rest: "proxy" \| "direct" \| {…urls} })` |
| `chartOptions` | — | Extra `TradingChart` options (pattern / swing API URLs, …) |
| `storageKey` | `"beturtl.chart.priceScale"` | Where price-axis preferences are saved; `null` disables |
| `layout` | `"1"` | Initial multi-chart layout id (see below) |
| `layoutStorageKey` | `"beturtl.chart.layout"` | Where the layout, each chart's symbol / interval and sync options are saved; `null` disables. A saved layout wins over the `symbol` / `resolution` / `layout` props |
| `onReady(chart)` | — | The `TradingChart` instance, for programmatic control. Fires for every chart in the layout |
| `onSymbolChange`, `onResolutionChange` | — | Fired when the selected chart's symbol / interval changes |
| `onLayoutChange(layout)` | — | Fired when the user picks another layout |
| `onFullscreenChange(on)` | — | Fired when the terminal enters or leaves fullscreen (toolbar button or Shift+F) |

## Multi-chart layouts

The layout button at the right of the toolbar splits the terminal into 1–16 charts (30 layouts,
ids in `CHART_LAYOUTS`). Click a chart to select it: the toolbar, drawing tools, indicators,
replay and keyboard shortcuts act on the selected chart. Each chart keeps its own symbol,
market, interval and chart type. New charts start as a copy of the selected one.

"Sync in layout" options:

| Option | Default | Effect |
|---|---|---|
| Symbol | off | Changing the symbol / market changes it on every chart |
| Interval | off | Changing the interval changes it on every chart |
| Crosshair | on | Crosshair shows on every chart at the same time; the price line only on charts of the same symbol |
| Time | off | Scrolling one chart scrolls the others to the same time, keeping their zoom |
| Date range | off | Scrolling or zooming one chart makes the others show the same date range |

The same sync is available on `TradingChart` for custom layouts: `onCrosshairMove` /
`setExternalCrosshair` and `onVisibleTimeRangeChange` / `getVisibleTimeRange` /
`setVisibleTimeRange(range, matchSpan)`. All positions are unix times, so charts on different
intervals line up.

Detection overlays (patterns, strength, swings, …) keep their summaries in shared stores, so
their info panels are shown on the selected chart only.

## Chart types

The chart type menu (next to the intervals) has 21 types in six groups. Hover a type for a short
explanation; star it to pin it to the toolbar. **Settings…** at the bottom of the menu opens the
selected type's options (colors, sources, box sizes, profile options). Each chart in the layout
keeps its own type and settings, saved with the layout.

| Group | Types |
| --- | --- |
| Candles | Bars, Candles, Hollow candles, Volume candles |
| Lines | Line, Line with markers, Step line |
| Areas | Area, HLC area, Baseline |
| Columns | Columns, High-low |
| Profiles | Volume footprint, Time price opportunity, Session volume profile |
| Transforms | Heikin Ashi, Renko, Line break, Kagi, Point & figure, Range |

- **Renko, Line break, Kagi, Point & figure, Range** build their own bars from the candles, so the
  time axis isn't even. Box size can come from ATR (default, 14), a fixed amount or a percent of
  price. Indicators are calculated on the bricks; drawings stay on their times when you switch.
- **Volume footprint** loads smaller candles for the bars on screen (1m for a 15m chart, 5m for 1h,
  …) and splits each bar into price rows of sell × buy volume, using Binance's taker-buy volume.
  It zooms in when selected; zoomed out it shows plain candles.
- **TPO** and **Session volume profile** group bars by UTC day (by week on a daily chart).

From code:

```ts
chart.setChartType("renko");
chart.setChartStyle(mergeChartStyle(defaultChartStyle(), { renko: { method: "traditional", boxSize: 500 } }));
chart.getBrickSize(); // 500
```

## Go to date

The calendar button in the toolbar (or ⌥G) opens **Go to**: the **Date** tab centres the
selected chart on a date and time, and **Custom range** shows exactly a from–to window.

Only one page of bars (1,000) around the date is fetched, so the jump is instant at any
distance. Older bars load as you scroll left and newer ones as you scroll right; live updates
pause until the loaded bars catch up with the present. The **»** button at the chart's
bottom-right (shown whenever the newest bar is off screen) returns to the latest bars and live
updates. With Time / Date range sync on, the other charts jump the same way.

From code:

```ts
await chart.goToDate(Date.UTC(2026, 7, 15, 14) / 1000);   // "ok" | "no-data"
await chart.goToRange(fromSec, toSec);
await chart.scrollToLatest();
chart.onLiveEdgeChange((atLiveEdge) => { /* show or hide your own button */ });
```

## Saving drawings

Drawings are saved per exchange + market + symbol + timeframe and come back when that chart is
opened again. By default they go to the browser's localStorage; give the terminal your own store to
keep them in your backend:

```tsx
import { TradingTerminal, type DrawingStore } from "@trading/terminal";

const apiStore: DrawingStore = {
  load: (key) => fetch(`/api/drawings/${encodeURIComponent(key)}`).then((r) => (r.ok ? r.json() : null)),
  save: (key, layout) =>
    fetch(`/api/drawings/${encodeURIComponent(key)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(layout),
    }).then(() => undefined),
};

<TradingTerminal
  drawingStore={apiStore}
  // e.g. your own symbol id instead of the symbol name
  drawingKey={({ market, symbol, resolution }) => `${symbolIdFor(market, symbol)}:${resolution}`}
/>;
```

| Prop | Default | Notes |
|---|---|---|
| `drawingStore` | localStorage | `{ load(key), save(key, layout) }`, sync or async; `null` turns saving off |
| `drawingKey` | `"binance:spot:BTCUSDT:15"` | Key a chart's layout is stored under |

A layout is `{ version: 1, savedAt, drawings: [...] }`. Each drawing keeps its type, label, color,
visibility and **every setting** (levels, text, pictures, lock, …), with points stored as **unix
time + price**, never as bar numbers, so they land on the right candles after a reload, when
older history loads, after a Go-to-date jump and in bar replay. Settings added in later versions take
their defaults when an older layout loads. Saving waits 400 ms after the last change and starts only
after the layout has loaded, so an empty chart never overwrites a stored layout.

## Saving indicators

Indicators are saved **per chart slot, not per symbol**: each of the (up to 16) layout slots keeps
its own set, which stays when that slot's symbol or timeframe changes and comes back after a reload.
Inputs, styles, levels, fills, visibility and placement are all kept, and so are links between
indicators (an SMA built on RSI still uses that RSI and sits in its pane).

| Prop | Default | Notes |
|---|---|---|
| `indicatorStore` | localStorage | `{ load(key), save(key, indicators) }`, sync or async; `null` turns saving off |
| `indicatorKey` | `slot => "chart-" + slot` | Key a slot's set is stored under (slot 0–15) |

From code: `chart.exportIndicators()` returns the set as plain data and
`chart.loadIndicators(saved)` restores it. Indicators saved before an input or plot existed load
with that input's default.

### Drawings from code

```ts
const id = chart.createDrawing({
  type: "fib_retracement",                      // any drawing tool
  points: [{ time: 1760425200, price: 80200 }, { time: 1760511600, price: 84100 }],
  color: "#ff9800",
  style: { fib: { labelFormat: "percent" } },   // any subset of the tool's settings
  text: "Weekly swing",                         // shorthand for style.text.content
  locked: true,
});
chart.updateDrawing(id, { points: [...], style: { fillOpacity: 25 }, visible: false });
chart.removeDrawing(id);

const layout = chart.exportDrawings();          // save anywhere
chart.loadDrawings(layout);                     // restore (replaces current drawings)
chart.onDrawingsChange((drawings) => { /* user added / moved / edited something */ });
```

## Trade lines (entry / TP / SL)

Add order lines from your code, show live P&L, and get the new price back when the user
drags one, so you can update your backend:

```ts
<TradingTerminal onReady={(chart) => {
  const entry = chart.createTradeLine({
    kind: "entry", label: "Long", price: 83450, side: "long", quantity: 0.5, currency: "USDT",
  });
  const tp = chart.createTradeLine({ kind: "tp", label: "TP1", price: 84200, entry });
  const sl = chart.createTradeLine({ kind: "sl", label: "SL", price: 83000, entry, cancellable: true });

  tp.onDrag((price, pnl) => { /* live while dragging: UI only */ });
  tp.onDragEnd(async (price, previous, pnl) => {
    try { await api.modifyOrder(id, { takeProfit: price }); }
    catch { tp.setPrice(previous); }            // backend refused: snap back
  });
  sl.onCancelClick(async () => { await api.cancelOrder(id); sl.remove(); });
}} />
```

| Option | Default | Notes |
|---|---|---|
| `kind` | — | `"entry" \| "tp" \| "sl" \| "custom"` (sets default colour and label) |
| `price` | — | Line price |
| `label` | kind name | Text in the coloured part of the label |
| `id` | generated | Your id; creating a line with an existing id replaces it |
| `side`, `quantity` | `"long"`, — | Set on the entry. TP/SL `quantity` overrides it for partial exits |
| `entry` | — | Entry line that TP/SL P&L is measured from |
| `currency` | — | Unit shown after the P&L, e.g. `"USDT"` (inherited from `entry`) |
| `draggable` | true (entry: false) | |
| `cancellable` | false | Shows a ✕ that fires `onCancelClick` |
| `color` | by kind | Entry blue, TP green, SL red, custom grey |
| `tickSize` | price precision | Drag step, e.g. `0.5` |
| `formatPnl(info, line)` | `+375.00 USDT (+0.90%)` | Custom P&L text |

Handle methods: `setPrice`, `setLabel`, `setQuantity`, `setSide`, `setColor`, `setDraggable`,
`setCancellable`, `remove`, `getPnl()`, plus `onDrag`, `onDragEnd`, `onCancelClick`
(each returns an unsubscribe function). Setters never fire the drag callbacks, so applying
values from your backend can't loop back into another API call.

P&L: entry lines use the live price; TP/SL lines use their own price relative to the entry
(`(price − entry) × quantity`, sign flipped for shorts). Lines are included in the price
auto-fit so they stay in view.

`onReady` runs again whenever the chart is recreated (symbol / market / timeframe change);
recreate your lines there.

## Trade markers (executions on candles)

Mark where entries / exits happened with arrows on their candles: buys are green ▲ under the
candle, sells red ▼ above it; exits have a hollow core. Hovering shows a ring at the exact fill
price and a tooltip.

```ts
chart.createTradeMarker({
  time: 1760425200,          // unix seconds — attaches to the candle containing this time
  price: 83120.2,            // fill price
  side: "buy",               // "buy" | "sell"
  kind: "entry",             // "entry" | "exit"
  quantity: 0.5,
  text: "ORD-0012 · opened long",   // tooltip details (use \n for more lines)
}).onClick((m) => openOrderDetails(m.id));

// Or replace everything at once, e.g. with history from your backend:
chart.setTradeMarkers(fills.map((f) => ({ time: f.time, price: f.price, side: f.side, kind: f.kind })));
```

| Option | Default | Notes |
|---|---|---|
| `time`, `price`, `side` | — | Required |
| `kind` | `"entry"` | Exits are drawn with a hollow arrow |
| `quantity` | — | Shown in the label and tooltip |
| `label` | `"Buy 0.5"` / `"Sell"` | Text beside the arrow; `""` hides it |
| `text` | — | Extra tooltip lines |
| `color` | green / red | |
| `id` | generated | Creating with an existing id replaces that marker |

Handle: `update(patch)`, `remove()`, `onClick(cb)`. Chart: `getTradeMarkers()`,
`getTradeMarker(id)`, `removeAllTradeMarkers()`. Markers on the same candle stack; markers
outside the loaded history are skipped until those candles load. Like trade lines, re-add them
in `onReady` after a symbol / timeframe change.

## Data

By default the terminal calls Binance directly from the browser. Spot, futures and
coin-M allow this; **options does not**, so for options pass
`datafeed={new BinanceDatafeed({ rest: "proxy" })}` and forward `/api/binance/options`
to `https://eapi.binance.com` on your server (see `apps/web/vite.config.ts`).

Pattern, swing and other detection overlays call the Python APIs under `/api/swings`;
point them elsewhere with `chartOptions`.

## Styling notes

- Colours are CSS variables on `:root` (`--accent`, `--bg-surface`, …); override them to re-theme.
- Base styles are scoped to the terminal and its pop-ups, so your page styles are untouched.
